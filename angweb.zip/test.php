<?php
	$mysqli = new mysqli('localhost','root','','angular');

	//Output any connection error
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}
	
	if(@$_GET['act']){
		
		$act = $_GET['act'];
		switch ($act) {
			case "class":
				
				$results = $mysqli->query("SELECT * FROM class");
				$array = selectall($results);
				echo json_encode($array);
				break;
			
			case "subject":
				
				$results = $mysqli->query("SELECT * FROM subject");
				$array = selectall($results);
				echo json_encode($array);
				break;
			
			case "teacher":
				
				$results = $mysqli->query("SELECT t.*, s.subject FROM teacher t LEFT JOIN subject s ON t.subject_id=s.id");
				$array = selectall($results);
				echo json_encode($array);
				break;
			
			case "student":
				
				$results = $mysqli->query("SELECT s.*, c.class FROM student s LEFT JOIN class c ON s.class_id=c.id");
				$array = selectall($results);
				echo json_encode($array);
				break;
			
			case "addclass":
				
				$postdata = file_get_contents("php://input");
				$data = json_decode($postdata, true);
				$class =$data['name'];
				
				$mysqli->query("INSERT INTO class (class) VALUES('$class')");
				
				$results = $mysqli->query("SELECT * FROM class");
				$array = selectall($results);
				echo json_encode($array);
				break;
			
			case "delclass":
				
				$id = $_GET['id'];
				$mysqli->query("DELETE FROM class WHERE id=$id");
				
				$results = $mysqli->query("SELECT * FROM class");
				$array = selectall($results);
				echo json_encode($array);
				break;
			
			case "addsub":
				
				$postdata = file_get_contents("php://input");
				$data = json_decode($postdata, true);
				$sub =$data['name'];
				
				$mysqli->query("INSERT INTO subject (subject) VALUES('$sub')");
				
				$results = $mysqli->query("SELECT * FROM subject");
				$array = selectall($results);
				echo json_encode($array);
				break;
				
			case "deletesub":
				
				$id = $_GET['id'];
				$mysqli->query("DELETE FROM subject WHERE id=$id");
				
				$results = $mysqli->query("SELECT * FROM subject");
				$array = selectall($results);
				echo json_encode($array);
				break;
			
			case "addtech":
				
				$postdata = file_get_contents("php://input");
				$data = json_decode($postdata, true);
				$subid =$data['sub'];
				$tech =$data['name'];
				
				$mysqli->query("INSERT INTO teacher (subject_id, teacher) VALUES('$subid','$tech')");
				
				$results = $mysqli->query("SELECT t.*, s.subject FROM teacher t LEFT JOIN subject s ON t.subject_id=s.id");
				$array = selectall($results);
				echo json_encode($array);
				break;
				
			case "deletetech":
				
				$id = $_GET['id'];
				$mysqli->query("DELETE FROM teacher WHERE id=$id");
				
				$results = $mysqli->query("SELECT t.*, s.subject FROM teacher t LEFT JOIN subject s ON t.subject_id=s.id");
				$array = selectall($results);
				echo json_encode($array);
				break;
				
			case "addstu":
				
				$postdata = file_get_contents("php://input");
				$data = json_decode($postdata, true);
				$stuid =$data['cla'];
				$stu =$data['name'];
				
				$mysqli->query("INSERT INTO student (class_id, student) VALUES('$stuid','$stu')");
				
				$results = $mysqli->query("SELECT s.*, c.class FROM student s LEFT JOIN class c ON s.class_id=c.id");
				$array = selectall($results);
				echo json_encode($array);
				break;
			
			case "deletestu":
				
				$id = $_GET['id'];
				$mysqli->query("DELETE FROM student WHERE id=$id");
				
				$results = $mysqli->query("SELECT s.*, c.class FROM student s LEFT JOIN class c ON s.class_id=c.id");
				$array = selectall($results);
				echo json_encode($array);
				break;
			
			
			default:
				$array = array('invalid request');
				echo json_encode($array);
		}
	
	
	}else{
		$array = array('invalid request');
		echo json_encode($array);
	}
	
	
/* FUNCTIONS */
function selectone($results){
	while($row = $results->fetch_assoc()) {
		$data = $row;
	}
	return $data;
}
function selectall($results){
	while($row = $results->fetch_assoc()) {
		$data[] = $row;
	}
	return $data;
}
function delete(){
	
}
	
?>