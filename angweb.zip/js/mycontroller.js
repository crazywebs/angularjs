/* controller */

var app = angular.module('myapp', ["ngRoute"]); // module creation.

/* controller start */

app.controller('mycontroller', function($scope, $http) { //controller creation.

	/* reading data from remote servers start */
	$http.get("test.php?act=class").then(function (response) {
			$scope.myclass = response.data;
		});
	$http.get("test.php?act=subject").then(function (response) {
			$scope.mysubject = response.data;
		});
	$http.get("test.php?act=teacher").then(function (response) {
			$scope.myteacher = response.data;
		});
	$http.get("test.php?act=student").then(function (response) {
			$scope.mystudent = response.data;
		});
	
	/* reading data from remote servers end */
	
	/* event functions start */
	$scope.orderByMe = function(x) { 
		$scope.myOrderBy = x;
	}
	
	$scope.form = {};
	$scope.submitForm = function()	{
		$http({
			url: "test.php?act=addclass",
			data: $scope.form,
			method: 'POST',
			headers : {'Content-Type': 'application/x-www-form-urlencoded'} 
		}).then(function (response) {
			$scope.myclass = response.data;
		});
	}
	$scope.submitSub = function()	{
		$http({
			url: "test.php?act=addsub",
			data: $scope.form,
			method: 'POST',
			headers : {'Content-Type': 'application/x-www-form-urlencoded'} 
		}).then(function (response) {
			$scope.mysubject = response.data;
		});
	}
	$scope.submitTech = function()	{
		$http({
			url: "test.php?act=addtech",
			data: $scope.form,
			method: 'POST',
			headers : {'Content-Type': 'application/x-www-form-urlencoded'} 
		}).then(function (response) {
			$scope.myteacher = response.data;
		});
	}
	$scope.submitstu = function()	{
		$http({
			url: "test.php?act=addstu",
			data: $scope.form,
			method: 'POST',
			headers : {'Content-Type': 'application/x-www-form-urlencoded'} 
		}).then(function (response) {
			$scope.mystudent = response.data;
		});
	}
	
	$scope.deleteclass = function(x) { 
		$http.get("test.php?act=delclass&id="+x).then(function (response) {
			$scope.myclass = response.data;
		});
		
	}
	$scope.deletesub = function(x) { 
		$http.get("test.php?act=deletesub&id="+x).then(function (response) {
			$scope.mysubject = response.data;
		});
		
	}
	$scope.deletetech = function(x) { 
		$http.get("test.php?act=deletetech&id="+x).then(function (response) {
			$scope.myteacher = response.data;
		});
		
	}
	$scope.deletestu = function(x) { 
		$http.get("test.php?act=deletestu&id="+x).then(function (response) {
			$scope.mystudent = response.data;
		});
		
	}
	
	/* event functions end */
	
});

/* controller end */

/* Routing start */

app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "home.html"
    })
    .when("/class", {
        templateUrl : "class.html"
    })
    .when("/subject", {
        templateUrl : "subject.html"
    })
	.when("/teacher", {
        templateUrl : "teacher.html"
    })
    .when("/student", {
        templateUrl : "student.html"
    });
});

/* Routing end */